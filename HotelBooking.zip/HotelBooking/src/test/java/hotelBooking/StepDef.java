package hotelBooking;

import static org.junit.Assert.assertEquals;

import java.util.Date;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import pages.HotelBookingBean;
import pages.LoginBean;
//import pages.SuccessBean;

public class StepDef {
	
	private WebDriver driver;
	private LoginBean loginBean;
	private HotelBookingBean hotelBookingBean;
	//private SuccessBean successbean;

	
	@Before
	public void setUp()
	{
		System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
		driver=new ChromeDriver();
		loginBean= new LoginBean(driver);
		hotelBookingBean=new HotelBookingBean(driver);
	}
	@Given("^login form is open$")
	public void login_form_is_open() throws Throwable {
		 driver.get("http://localhost:8082/HotelBooking/login.html");
	}
	
	@When("^I blindly click on login$")
	public void i_blindly_click_on_login() throws Throwable {
		loginBean.setBtn();
	}

	@Then("^Alert message for UserName will be raised$")
	public void alert_message_for_UserName_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the UserName");
    	Thread.sleep(500);
    	}
    	
	

	@When("^I enter the UserName and press login$")
	public void i_enter_the_UserName_and_press_login() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		loginBean.setUserName("cepgemini");
		loginBean.setBtn(); 
	}

	@Then("^Alert message for Password is raised$")
	public void alert_message_for_Password_is_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Password");
    	Thread.sleep(500);
	}
	@When("^I enter the Password and press login$")
	public void i_enter_the_Password_and_press_login() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		loginBean.setUserName("cepgemini");
		loginBean.setPassword("capg1234");
		loginBean.setBtn(); 
	}
	@Then("^I get an alert for login details validated and I am sent to hotelBooking\\.html page$")
	public void i_get_an_alert_for_login_details_validated_and_I_am_sent_to_hotelBooking_html_page() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "login details are validated.");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^hotel booking page is open and i blinldly press confirm booking$")
	public void hotel_booking_page_is_open_and_i_blinldly_press_confirm_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    throw new PendingException();
	}

	@Then("^Alert message for First Name is raised$")
	public void alert_message_for_First_Name_is_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the First Name.");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the First Name and press next$")
	public void i_enter_the_First_Name_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		hotelBookingBean.setFirstName("Capg");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for Last Name will be raised$")
	public void alert_message_for_Last_Name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the last Name.");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the Last Name and press next$")
	public void i_enter_the_Last_Name_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for Email will be raised$")
	public void alert_message_for_Email_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Email");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the Email and press next$")
	public void i_enter_the_Email_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for Mobile No will be raised$")
	public void alert_message_for_Mobile_No_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Mobile No");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the Mobile no and press next$")
	public void i_enter_the_Mobile_no_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for Address name will be raised$")
	public void alert_message_for_Address_name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Address");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the Address and press next$")
	public void i_enter_the_Address_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setAddress("mahindra world city");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for enter City will be raised$")
	public void alert_message_for_enter_City_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the City");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the City and press next$")
	public void i_enter_the_City_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setAddress("mahindra world city");
		hotelBookingBean.setCity("Chennai");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for enter State will be raised$")
	public void alert_message_for_enter_State_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the State");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the State and press next$")
	public void i_enter_the_State_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setAddress("mahindra world city");
		hotelBookingBean.setCity("Chennai");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for Number of guest staying will be raised$")
	public void alert_message_for_Number_of_guest_staying_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Number of guest staying");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the Number of guest staying and press next$")
	public void i_enter_the_Number_of_guest_staying_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setAddress("mahindra world city");
		hotelBookingBean.setCity("Chennai");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setPersons("1");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for Card Holder Name will be raised$")
	public void alert_message_for_Card_Holder_Name_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Card Holder Name");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter Card Holder Name and press next$")
	public void i_enter_Card_Holder_Name_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setAddress("mahindra world city");
		hotelBookingBean.setCity("Chennai");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setPersons("1");
		hotelBookingBean.setRooms("1");
		hotelBookingBean.setCardHolderName("capg");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for enter Debit Card Number will be raised$")
	public void alert_message_for_enter_Debit_Card_Number_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Debit Card Number");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the enter Debit Card Number press next$")
	public void i_enter_the_enter_Debit_Card_Number_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setAddress("mahindra world city");
		hotelBookingBean.setCity("Chennai");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setPersons("1");
		hotelBookingBean.setRooms("1");
		hotelBookingBean.setCardHolderName("capg");
		hotelBookingBean.setDbCardNumber("1234123412341234");
		hotelBookingBean.setBtn2();
		}

	@Then("^Alert message for enter CVV no will be raised$")
	public void alert_message_for_enter_CVV_no_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the CVV");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the CVV and press next$")
	public void i_enter_the_CVV_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setAddress("mahindra world city");
		hotelBookingBean.setCity("Chennai");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setPersons("1");
		hotelBookingBean.setRooms("1");
		hotelBookingBean.setCardHolderName("capg");
		hotelBookingBean.setDbCardNumber("1234123412341234");
		hotelBookingBean.setCvv("564");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for enter Expiration month will be raised$")
	public void alert_message_for_enter_Expiration_month_will_be_raised() throws Throwable {
	    assertEquals(driver.switchTo().alert().getText(), "Please fill the Expiration month");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the Expiration month and press next$")
	public void i_enter_the_Expiration_month_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setAddress("mahindra world city");
		hotelBookingBean.setCity("Chennai");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setPersons("1");
		hotelBookingBean.setRooms("1");
		hotelBookingBean.setCardHolderName("capg");
		hotelBookingBean.setDbCardNumber("1234123412341234");
		hotelBookingBean.setCvv("564");
		hotelBookingBean.setExpiryDate("08");
		hotelBookingBean.setBtn2();
	}

	@Then("^Alert message for Expiration Year will be raised$")
	public void alert_message_for_Expiration_Year_will_be_raised() throws Throwable {
		assertEquals(driver.switchTo().alert().getText(), "Please fill the Expiration Year");
    	Thread.sleep(1500);
    	driver.switchTo().alert().accept();
	}

	@When("^I enter the Expiration Year and press next$")
	public void i_enter_the_Expiration_Year_and_press_next() throws Throwable {
		driver.switchTo().alert().accept();
		driver.navigate().refresh();
		hotelBookingBean.setFirstName("Cap");
		hotelBookingBean.setLastName("Gemini");
		hotelBookingBean.setEmail("cag@capgemini.com");
		hotelBookingBean.setPhone("9876545678");
		hotelBookingBean.setAddress("mahindra world city");
		hotelBookingBean.setCity("Chennai");
		hotelBookingBean.setState("Tamilnadu");
		hotelBookingBean.setPersons("1");
		hotelBookingBean.setRooms("1");
		hotelBookingBean.setCardHolderName("capg");
		hotelBookingBean.setDbCardNumber("1234123412341234");
		hotelBookingBean.setCvv("564");
		hotelBookingBean.setExpiryDate("08");
		hotelBookingBean.setExpiryYear("2020");
		hotelBookingBean.setBtn2();
	}

	@Then("^I get an alert for login details validated and I am sent to success\\.html page$")
	public void i_get_an_alert_for_login_details_validated_and_I_am_sent_to_success_html_page() throws Throwable {
	   
	}

	
}
