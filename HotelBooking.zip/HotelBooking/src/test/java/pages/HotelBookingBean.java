package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingBean {

	WebDriver driver;
	
	@FindBy(name="txtFN")
	private WebElement txtFN;
	@FindBy(name="txtLN")
	private WebElement txtLN;
	@FindBy(name="Email")
	private WebElement Email;
	@FindBy(name="Phone")
	private WebElement Phone;
	@FindBy(name="address")
	private WebElement address;
	@FindBy(name="city")
	private WebElement city;
	@FindBy(name="state")
	private WebElement state;
	@FindBy(name="persons")
	private WebElement persons;
	@FindBy(name="rooms")
	private WebElement rooms;
	@FindBy(name="txtFN")
	private WebElement txtFN1;
	@FindBy(name="debit")
	private WebElement debit;
	@FindBy(name="cvv")
	private WebElement cvv;
	@FindBy(name="month")
	private WebElement month;
	@FindBy(name="year")
	private WebElement year;
	@FindBy(name="btn")
	private WebElement btn2;
	public HotelBookingBean(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	public void setBtn2() {
		this.btn2.click();
	}
	
	public void setFirstName(String firstName) {
		this.txtFN.sendKeys(firstName); 
	}

	public void setLastName(String lastName) {
		this.txtLN.sendKeys(lastName);
	}

	public void setEmail(String email) {
		this.Email.sendKeys(email);
	}

	public void setPhone(String phone) {
		this.Phone.sendKeys(phone);
	}
	public void setAddress(String area) {
		this.address.sendKeys(area);
	}

	public void setCity(String c) {
		Select sel= new Select(city);
		sel.selectByVisibleText(c);
	}

	public void setState(String s) {
		Select st=new Select(state);
		st.selectByVisibleText(s);
	}

	public void setPersons(String pe) {
		Select p= new Select(persons);
		p.selectByVisibleText(pe);
	}
	public void setRooms(String room) {
		this.rooms.sendKeys(room);
	}
	public void setCardHolderName(String cardHolderName) {
		this.debit.sendKeys(cardHolderName);
	}

	public void setDbCardNumber(String dbCardNumber) {
		this.debit.sendKeys(dbCardNumber);
	}

	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public void setExpiryDate(String expiryDate) {
		this.month.sendKeys(expiryDate);
	}

	public void setExpiryYear(String expiryYear) {
		this.year.sendKeys(expiryYear);
	}
	
	
}
