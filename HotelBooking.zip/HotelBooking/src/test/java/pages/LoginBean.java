package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginBean {

	WebDriver driver;
	@FindBy(name="userName")
	private WebElement UserName;
	
	@FindBy(name="password")
	private WebElement Password;
	
	@FindBy(name="Address")
	private WebElement btn;
	
	public LoginBean(WebDriver driver) {
		
		this.driver=driver;
		PageFactory.initElements(driver, this);
	}
	
	public void setBtn() {
		this.btn.click();
	}
	
	public void setUserName(String userName) {
		this.UserName.sendKeys(userName); 
	}

	public void setPassword(String password) {
		this.Password.sendKeys(password);
	}
	


}
