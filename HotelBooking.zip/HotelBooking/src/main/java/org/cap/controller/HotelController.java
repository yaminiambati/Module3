package org.cap.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HotelController {
	
	@RequestMapping("/")
	public String openFirst() {
		return "login";
	}
	
	@RequestMapping("/hotelbooking")
	public String openSecond() {
		return "hotelbooking";
	}
	
	@RequestMapping("/success")
	public String openSuccess() {
		return "success";
	}
}
